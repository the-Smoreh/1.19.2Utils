function createComponent(template) {
    return {
        template: template
    }
}

export { createComponent }